import { UppDirective } from './upp.directive';

describe('UppDirective', () => {
  it('should create an instance', () => {
    const directive = new UppDirective();
    expect(directive).toBeTruthy();
  });
});
