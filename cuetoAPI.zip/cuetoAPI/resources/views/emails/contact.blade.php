<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<p><strong>Reporte de inspeccion con remito: </strong>{!!$remito!!}</p>
	<br>
	<p><strong>Descargar el .pdf adjunto</strong></p>
	<br><br>
	<p>Un trabajo bien hecho es aquel que se realiza con Seguridad y Calidad, preservando la salud de los trabajadores y cuando el ambiente donde se desarrolla.</p>
	<br>
	<p>Saludos cordiales, el equipo de Tecprecinc.</p>
</body>
</html>